---
name: StellarX Submission
about: Submit Public Market Stall Rental Ledger
title: "Public Market Stall Rental Ledger"
labels: stellarx, submission
assignees: ""
---

## Project

Public Market Stall Rental Ledger

## Idea Number

59

## Summary

Public Market Stall Rental Ledger gives operators a shared settlement score trail, signed wallet actions, and a Soroban-backed release path that can be audited from dashboard to ledger.

## Stellar Usage

- Stellar testnet
- Soroban contract
- Freighter wallet
- Stellar SDK
- XLM/USDC SAC references
