# Submission Guidelines

Submit Public Market Stall Rental Ledger with:

- a working frontend demo,
- an API route that returns a Stellar action quote,
- a Soroban contract test,
- testnet account and contract deployment notes,
- screenshots of the main workflow.
